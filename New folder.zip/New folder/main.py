from fastapi import FastAPI
from pydantic import BaseModel
from pydantic import BaseModel, Field
from typing import List, Optional
app = FastAPI()

class Student(BaseModel):
    id: int = Field(..., description="Unique identifier for the student")
    name: str = Field(..., min_length=2, max_length=50, description="Student's full name")
    email: str = Field(..., description="Student's email address")
    tests_taken: List[int] = []

class Test(BaseModel):
    id: int = Field(..., description="Unique identifier for the test")
    name: str = Field(..., min_length=2, max_length=100, description="Name of the test")
    max_score: int = Field(..., description="Maximum possible score")

class TestResult(BaseModel):
    student_id: int = Field(..., description="ID of the student taking the test")
    test_id: int = Field(..., description="ID of the test taken")
    score: int = Field(..., description="Score obtained in the test")

class ResponseMessage(BaseModel):
    message: str



result_db = [ 
  {
    'id': 1,
    'name': 'John',
    'age': 30
  },
  {
    'id': 2,
    'name': 'Jack',
    'age': 40
  },
  {
    'id': 3,
    'name': 'Jill',
    'age': 50
  }
] 

db = [
    {
        'id': 1,
        'name': 'John',
        'email': 'john@example.com',
    },
    {
        'id': 2,
        'name': 'Jane',
        'email': 'jane@example.com',
    },
    {
        'id': 3,
        'name': 'Bob',
        'email': 'bob@example.com',
    }
]

test_db = [
  {
    'id': 1,
    'name': 'Math',
    'max_score': 100
  },
  {
    'id': 2,
    'name': 'English',
    'max_score': 100
  },
  {
    'id': 3,
    'name': 'Science',
    'max_score': 100
  }
]


# @app.get("/")
# def read_root():
#     return {"Hello": "World!"}

# @app.delete('/student/{id}')
# def delete_student(id: int):
#   for student in db:
#     if student['id'] == id:
#       db.remove(student)
#       return student    
#     return {"error": "Student not found"}


# @app.put('/update/{id}')
# def update(id: int, student: Student):
#     for s in db:
#         if s['id'] == id:
#             s['name'] = student.name
#             s['age'] = student.age
#             return s
#     return {"error": "Student not found"}

# @app.delete('/delete/{id}')
# def delete(id: int):
#     for student in db:
#         if student['id'] == id:
#             db.remove(student)
#             return student
#     return {"error": "Student not found"}

@app.post('/add')
def add(student: Student):
  for s in db:
    if s['name'] == student.name:
      return {"error": "Student already exists"}
    else:
      new_student = student.model_dump()
      new_student['id'] = len(db) + 1
      db.append(new_student)
      return new_student

@app.get('/get/{id}')
def get(id: int):
  for student in db:
    if student['id'] == id:
      return student
    return {"error": "Student not found"}


@app.get('/get_all')
def get_all():
  return db

@app.post('/tests')
def add_test(test: Test):
  for t in test_db:
    if t['name'] == test.name and t['max_score'] == test.max_score:
      return {"error": "Test already exists"} 
    else:
      new_test = test.model_dump()
      new_test['id'] = len(test_db) + 1
      test_db.append(new_test)
      return new_test

@app.get('/tests/{id}')
def get_test(id: int):
  for test in test_db:
    if test['id'] == id:
      return test
    return {"error": "Test not found"}


@app.get('/tests')
def get_all_tests():
  return test_db


@app.post('/results')
def add_result(result: TestResult):
  for r in result_db:
    if r['student_id'] == result.student_id and r['test_id'] == result.test_id and r['score'] == result.score:
      return {"error": "Result already exists"}
    else:
      new_result = result.dict()
      new_result['id'] = len(result_db) + 1
      result_db.append(new_result)
      return new_result
    
    
@app.get('/results/student/{id}')
def get_student_results(id: int):
  results = []
  for result in result_db:
    if result['student_id'] == id:
      results.append(result)
      return results
    return {"error": "Student not found"}
  
  
@app.get('/results/test/{id}')
def get_test_results(id: int): 
  results = []
  for result in result_db:
    if result['test_id'] == id:
      results.append(result)
      return results
    return {"error": "Test not found"}
  
  

@app.get('/results/test/{test_id}/average')
def get_test_average(test_id: int):
  results = []
  for result in result_db:
    if result['test_id'] == test_id and result['score'] != 0:
      results.append(result['score'])
      return results
    return {"error": "Test not found"}


@app.get('/results/test/{test_id}/highest')
def get_test_highest(test_id: int):
  results = []
  for result in result_db:
    if result['test_id'] == test_id:
      results.append(result['score'])
      return max(results)
    return {"error": "Test not found"}
  