from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_root():
    response = client.get('/')
    assert response.status_code == 200
    assert response.json() == {"Hello": "World!"}

def test_add():
    response = client.post('/add', json={'age': 30, 'name': 'John'})
    assert response.status_code == 200
    assert response.json() == {"age": 30, "name": "John", "id": 4}

def test_update():
    response = client.put('/update/1', json={'age': 30, 'name': 'Jack'})
    assert response.status_code == 200
    assert response.json() == {'age': 30, 'id': 1, 'name': 'Jack'}

def test_delete():
    response = client.delete('/delete/1')
    assert response.status_code == 200
    assert response.json() == {'age': 30, 'id': 1, 'name': 'Jack'}
    
    
    
